package org.mapdb;

public interface CC {
   boolean PARANOID = false;
}
