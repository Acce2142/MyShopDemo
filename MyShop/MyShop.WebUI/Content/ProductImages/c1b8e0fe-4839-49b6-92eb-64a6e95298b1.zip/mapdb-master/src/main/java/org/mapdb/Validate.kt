package org.mapdb

interface Validate{

    fun validate()
}