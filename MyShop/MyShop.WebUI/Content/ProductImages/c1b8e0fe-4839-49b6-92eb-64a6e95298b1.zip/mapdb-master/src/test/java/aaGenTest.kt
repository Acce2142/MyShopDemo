import org.junit.Test

class genTest{

    @Test
    fun main(){
        AACodeGen()
    }
}